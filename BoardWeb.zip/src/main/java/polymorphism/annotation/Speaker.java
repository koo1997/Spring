package polymorphism.annotation;

public interface Speaker {

	void volumeUp();

	void volumeDown();

}