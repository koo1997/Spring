create table board (
seq int primary key  auto_increment ,
title varchar(200),
writer varchar(20),
content varchar(2000),
regdate date default now(),
cnt int default 0
);